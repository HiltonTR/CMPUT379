Hilton Truong 1615505
Assignment 1 CMPUT 379

Acknowledgements:
all the acknowledgements for the code are in the code as comments and sources have been provided.
For conceptual items such as the structure, my previous assignment from when I took the course last
fall was used. Course notes from this term and W22 from Professor Elmallah were also referenced. 
Ideas on how the program should be structured (3 files and what would go where) were also 
discussed with classmates Jakob Lau and Mohammed Saleh.