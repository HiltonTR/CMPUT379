#ifndef GENERAL_H
#define GENERAL_H

#include <string>
#include <utility>
#include <iostream>
#include <vector>

using namespace std;

pair<string, vector<int>> readPkt(string &s);

#endif