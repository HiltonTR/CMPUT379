#ifndef MASTER_H
#define MASTER_H

#include <stdint.h>

void MasterLoop(int numSwitches, int portNumber);

#endif